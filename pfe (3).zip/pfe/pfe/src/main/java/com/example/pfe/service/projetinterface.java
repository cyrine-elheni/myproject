package com.example.pfe.service;

import java.util.List;

import com.example.pfe.model.expected_metrics;
import com.example.pfe.model.projet;
import com.example.pfe.model.projetDTO;


public interface projetinterface {
	public projet createprojet(projetDTO projetDTO);
	public projet updateprojet (projetDTO projetDTO);
    public void deleteprojet (String projetid);
    public projet getprojet(String projetid);
    public List<projet> getallprojets();
    List<expected_metrics> getprojetmetrics(String projetid);
   
}
