package com.example.pfe.model;




import java.util.List;

import org.slf4j.LoggerFactory;

import ch.qos.logback.classic.Logger;

public class stbDTO {
	private String sid;
	private String android;

	private List<metricsDTO> metricsDTO  ;
	public void setSid(String sid) {
		this.sid = sid;
	}
	public String getSid() {
		return sid;
	}
	
	private static final Logger logger = (Logger) LoggerFactory.getLogger(stbDTO.class);

	
	public List<metricsDTO> getMetrics() {
		logger.warn("metricsDTO:"+metricsDTO);
		return metricsDTO;
	}
	public void setMetrics(List<metricsDTO> metricsDTO) {
		this.metricsDTO = metricsDTO;

	}
	
	public void setAndroid(String android) {
		this.android = android;
	}
	public String getAndroid() {
		return android;
	}

	}	

