package com.example.pfe.response;

public class loginmessage {
    private String message;
    private Boolean status;
    private String role;

    public loginmessage(String message, Boolean status, String role) {
        this.message = message;
        this.status = status;
        this.role = role;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
