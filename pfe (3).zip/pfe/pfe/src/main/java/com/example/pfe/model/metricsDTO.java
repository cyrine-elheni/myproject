package com.example.pfe.model;

public class metricsDTO {
	private String datamodel;
    private String valeur ;
  //  private String mid;
	public String getDatamodel() {
		return datamodel;
	}
	public void setDatamodel(String datamodel) {
		this.datamodel = datamodel;
	}
	public String getValeur() {
		return valeur;
	}
	public void setValeur(String valeur) {
		this.valeur = valeur;
	}
/*	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
*/	

	
}