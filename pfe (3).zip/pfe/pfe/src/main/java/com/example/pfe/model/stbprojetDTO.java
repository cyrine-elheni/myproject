package com.example.pfe.model;

public class stbprojetDTO {
	private String pid;
    private String sid;
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getPid() {
		return pid;
	}

}
