package com.example.pfe.service;

import java.util.List;

import com.example.pfe.model.loginDTO;
import com.example.pfe.model.user;
//import com.example.pfe.model.loginDTO;
import com.example.pfe.model.userDTO;
//import com.example.pfe.response.loginmessage;
import com.example.pfe.response.loginmessage;

import jakarta.servlet.http.HttpServletResponse;

public interface userinterface {
String adduser(userDTO userDTO);
loginmessage loginuser(loginDTO loginDTO);
user getuser(String matricule);
List<user> getallusers();
}
