package com.example.pfe.model;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Entity
@Data
@Table(name="projet")
public class projet {
	@Id
	@Column(name = "pid")
    private String pid;
	@Column(name="pname")
	private String pname;
	
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		 this.pid = pid;
	}
	
	@OneToMany
    private List<stb> stbs;

	public List<stb> getStbs() {
		return stbs;
	}
	public void setStbs(List<stb> stbs) {
		this.stbs = stbs;
	}
	
public List<expected_metrics> getExpected_metricslist() {
		return expected_metricslist;
	}
	public void setExpected_metricslist(List<expected_metrics> expected_metricslist) {
		this.expected_metricslist = expected_metricslist;
	}
	
	@JsonManagedReference
	@OneToMany(mappedBy="projet")
private List<expected_metrics> expected_metricslist ;
	

	
	
	
	
}
