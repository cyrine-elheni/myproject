package com.example.pfe.service;

import java.util.ArrayList;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.pfe.model.expected_metrics;

import com.example.pfe.model.projet;
import com.example.pfe.model.projetDTO;
import com.example.pfe.model.repository.e_metricsrepository;
import com.example.pfe.model.repository.projetrepository;
import jakarta.transaction.Transactional;
import com.example.pfe.model.*;
@Transactional
@Service
public class projetservice implements projetinterface{
	
	private final projetrepository projetrepo;
	private final e_metricsrepository e_metricsrepo;

	
	@Autowired
	public projetservice(projetrepository projetrepo,e_metricsrepository e_metricsrepo) {
	super();
	this.projetrepo = projetrepo;
	this.e_metricsrepo=e_metricsrepo;
	
}
/*	public projet createprojet(projetDTO projetDTO) {
		 projet projet1 = new projet();
	        projet1.setPid(projetDTO.getPid());
	        projet1.setPname(projetDTO.getPname());
	        return projetrepo.save(projet1);
	}*/
	@Override
	public projet createprojet(projetDTO projetDTO) {
	    projet projet1 = new projet();
	    projet1.setPid(projetDTO.getPid());
	    projet1.setPname(projetDTO.getPname());

	    if (projet1.getExpected_metricslist() == null) {
	    	projet1.setExpected_metricslist(new ArrayList<>());
	    }

	    if (projetDTO.getExpected_metrics() != null) {
	        for (expected_metrics expected_metricsDTO1 :projetDTO.getExpected_metrics()) {
	        	expected_metrics expected_metrics1 = new expected_metrics();
	        	//expected_metrics1.setE_mid(expected_metricsDTO1.getE_mid());
	        	expected_metrics1.setExpected_datamodel(expected_metricsDTO1.getExpected_datamodel());
	        	expected_metrics1.setExpected_valeur(expected_metricsDTO1.getExpected_valeur());
	        	expected_metrics1.setProjet(projet1);
	        	projet1.getExpected_metricslist().add(expected_metrics1);
	           e_metricsrepo.save(expected_metrics1);
	        }
	    }
	        
	    // Save STB and associated metrics
	    return projetrepo.save(projet1);
	}
	

/*	@Override
	public projet updateprojet(projetDTO projetDTO) {
		 projet projet1 = new projet();
	        projet1.setPid(projetDTO.getPid());
	        projet1.setPname(projetDTO.getPname());
	        return projetrepo.save(projet1);
		
	}
*/
	@Override
	public String deleteprojet(String projetid) {
		projetrepo.deleteById(projetid);
		return "success";
	}


	@Override
	public projet getprojet(String projetid) {
		return projetrepo.findById(projetid).get();
		}

	@Override
	public List<expected_metrics> getprojetmetrics(String projetid) {
		 projet projet1=projetrepo.findById(projetid).get();
		 projet1.getExpected_metricslist();
        return projet1.getExpected_metricslist();
		}



	@Override
	public List<projet> getallprojets() {
		 return projetrepo.findAll();
		}
	@Override
	public projet updateprojet(projetDTO projetDTO) {
		// TODO Auto-generated method stub
		return null;
	}



}
