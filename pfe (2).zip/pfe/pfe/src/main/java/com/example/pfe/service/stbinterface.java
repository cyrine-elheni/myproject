package com.example.pfe.service;

import java.util.List;
import java.util.Optional;

import com.example.pfe.model.expected_metrics;
import com.example.pfe.model.metrics;
import com.example.pfe.model.metricsDTO;
import com.example.pfe.model.resultat;
import com.example.pfe.model.stb;
import com.example.pfe.model.stbDTO;
import com.example.pfe.model.stbprojet;

public interface stbinterface {
	public stb createstb(stbDTO stbDTO);
	public stb updatestb(stbDTO stbDTO);
    public String deletestb (String stbid);
    public stb getstb(String stbid);
    public List<metrics> getstbmetrics(String stbid);
    public List<stb> getallstbs();
    void addstbtoprojet(String pid,String sid);
     String getprojetbysid(String sid);

     boolean compareDataModels(List<metrics> stbmetrics, List<expected_metrics> expectedmetrics);
     boolean compareValeurs(metrics stbmetrics, expected_metrics expectedmetrics);
     resultat comparemetrics(String stbSid);
}
