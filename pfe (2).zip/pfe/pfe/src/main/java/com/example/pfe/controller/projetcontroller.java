package com.example.pfe.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.pfe.model.expected_metrics;
import com.example.pfe.model.projet;
import com.example.pfe.model.projetDTO;
import com.example.pfe.model.stb;
import com.example.pfe.model.stbDTO;
import com.example.pfe.service.projetservice;
@CrossOrigin
@RestController
@RequestMapping(path = "projetsima")
public class projetcontroller {

	private final projetservice projetservice;
	@Autowired
	public projetcontroller(projetservice projetservice) {
	this.projetservice= projetservice;
	}

	
	@GetMapping("{pid}")
	public projet getprojectdetails(@PathVariable String pid ) {
		return projetservice.getprojet(pid) ;
	}
	@GetMapping("/metrics/{pid}")
	public List<expected_metrics> getprojetmetrics(@PathVariable String pid ) {
		return projetservice.getprojetmetrics(pid) ;
		
	}
	
	@GetMapping(value ="all" )
	public List<projet> getprojet(){
	return projetservice.getallprojets();
	}
	
    @PostMapping("/create")
    public ResponseEntity<String> createprojet(@RequestBody projetDTO projetDTO) {
        projet createdprojet= projetservice.createprojet(projetDTO);
        if (createdprojet != null) {
            return ResponseEntity.ok("projet created successfully");
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to create projet");
        }
    }
	
	
	/*@PostMapping
	public String createprojectdetails(@RequestBody projetDTO projetDTO ) {
		 projetservice.createprojet(projetDTO) ;
		 return "project created successfully";	
	}*/
	/*@PutMapping
	public String updateprojectdetails(@RequestBody projet projet ) {
		 projetservice. updateprojet(projet) ;
		 return "project updated successfully";
	
	}
	*/
	@DeleteMapping("{pname}")
	public String deleteprojectdetails(@PathVariable String pname  ) {
		 projetservice.deleteprojet(pname)  ;
		 return "project deleted successfully";	
	}
}
