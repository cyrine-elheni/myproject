package com.example.pfe.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.pfe.model.loginDTO;
import com.example.pfe.model.projet;
//import com.example.pfe.model.loginDTO;
import com.example.pfe.model.user;
import com.example.pfe.model.userDTO;
import com.example.pfe.model.repository.userepository;
//import com.example.pfe.response.loginmessage;
import com.example.pfe.response.loginmessage;

import jakarta.transaction.Transactional;
@Transactional 
@Service
public class userservice implements userinterface  {
	
	@Autowired
	private userepository userepo;
	@Autowired 
	private PasswordEncoder passwordEncoder;
    public userservice(userepository userepo) {
	this.userepo=userepo;
}
	/*@Override
	public String adduser(userDTO userDTO) {
		user user1=new user();
		user1.setMatricule(userDTO.getMatricule());
		user1.setEmail(userDTO.getEmail());
		user1.setPassword(userDTO.getPassword());
	//	this.passwordEncoder.encode(userDTO.getPassword());
		userepo.save(user1);
		return "success";
	}*/
	@Override
	public loginmessage loginuser(loginDTO loginDTO) {
		 String msg = "";
		    user user1 = userepo.findByMatricule(loginDTO.getMatricule());
		    if (user1 != null) {
		        String password = loginDTO.getPassword();
		        String storedPassword = user1.getPassword();
		        boolean isPwdRight = passwordEncoder.matches(password, storedPassword);

		        if (isPwdRight) {
		            Optional<user> user2 = userepo.findOneByMatriculeAndPassword(loginDTO.getMatricule(), storedPassword);
		            if (user2.isPresent()) {
		                // Récupérer le rôle de l'utilisateur
		                String role = user2.get().getRoles();
		                return new loginmessage("login success", true, role);
		            } else {
		                return new loginmessage("login failed", false, null);
		            }
		        } else {
		            return new loginmessage("password not match", false, null);
		        }
		    } else {
		        return new loginmessage("Matricule does not exist", false, null);
		    }
		}
	@Override
		public user getuser(String matricule) {
			return userepo.findByMatricule(matricule);
			}
	@Override
	public List<user> getallusers() {
		 return userepo.findAll();
		}
	@Override
	public String adduser(userDTO userDTO) {
		// TODO Auto-generated method stub
		return null;
	}


	

		}
