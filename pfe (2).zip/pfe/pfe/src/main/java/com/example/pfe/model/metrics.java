package com.example.pfe.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.example.pfe.model.*;
@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@Table(name="metrics")
public class metrics {

   
    /*@Id
    @Column(name= "mid")
    private String mid;
  */
    

	@Id
	@Column(name= "datamodel")
    private String datamodel;
  
    
    @Column(name= "valeur", columnDefinition = "TEXT")
    private String valeur;

	public String getDatamodel() {
		return datamodel;
	}

	public void setDatamodel(String datamodel) {
		this.datamodel = datamodel;
	}

	public String getValeur() {
		return valeur;
	}

	public void setValeur(String valeur) {
		this.valeur = valeur;
	}
	
    

	public stb getStb() {
		return stb;
	}

	public void setStb(stb stb) {
		this.stb = stb;
	}
    @JsonBackReference
	@ManyToOne(cascade = CascadeType.ALL)
	private stb stb;

	







    

}
