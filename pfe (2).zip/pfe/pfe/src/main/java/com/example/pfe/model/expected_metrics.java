package com.example.pfe.model;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@Table(name="expected_metrics")
public class expected_metrics {

	   public String getExpected_datamodel() {
		return expected_datamodel;
	}


	public void setExpected_datamodel(String expected_datamodel) {
		this.expected_datamodel = expected_datamodel;
	}


	public String getExpected_valeur() {
		return expected_valeur;
	}


	public void setExpected_valeur(String expected_valeur) {
		this.expected_valeur = expected_valeur;
	}


	
	    public projet getProjet() {
		return projet;
	}


	public void setProjet(projet projet) {
		this.projet = projet;
	}

	@Id
		@Column(name= "expected_datamodel")
	    private String expected_datamodel;
	  
	    
	    @Column(name= "expected_valeur", columnDefinition = "TEXT")
	    private String expected_valeur;

	    @JsonBackReference
	    @ManyToOne(cascade = CascadeType.ALL)
		private projet projet;






	

	

	
}
