package com.example.pfe.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.pfe.response.*;
import com.example.pfe.model.loginDTO;
import com.example.pfe.model.projet;
import com.example.pfe.model.user;
import com.example.pfe.model.userDTO;
import com.example.pfe.model.repository.userepository;
import com.example.pfe.service.*;
@CrossOrigin
@RestController
@RequestMapping(path = "usersima")
public class usercontroller {
   @Autowired
   private userservice userservice;
   private final userepository userepo;
public usercontroller(userepository userepo) {
	this.userepo=userepo;
}
	@Autowired
private PasswordEncoder passwordencoder;
	
	@GetMapping("/")
	public String gologinpage(@PathVariable String pid ) {
		return "this is publickly accessible" ;
	}
	@PostMapping(path="/save")
	public ResponseEntity<Object> saveUser(@RequestBody user user) {

	    user existingUser = userepo.findByMatricule(user.getMatricule());
	    
	    if(existingUser != null) {
	        existingUser.setPassword(passwordencoder.encode(user.getPassword()));
	        existingUser.setRoles(user.getRoles());
	        existingUser.setEmail(user.getEmail());

	        
	        user updatedUser = userepo.save(existingUser);
	        
	        if (updatedUser != null && updatedUser.getId() > 0) {
	            return ResponseEntity.ok("User was updated successfully");
	        } else {
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error, User not updated");
	        }
	    } else {
	        user.setPassword(passwordencoder.encode(user.getPassword()));
	        user savedUser = userepo.save(user);
	        
	        if (savedUser != null && savedUser.getId() > 0) {
	            return ResponseEntity.ok("User was saved successfully");
	        } else {
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error, User not saved");
	        }
	    }
	}
	@PutMapping(path="/update")
	public ResponseEntity<Object> updateUser(@RequestBody user user) {

	    user existingUser = userepo.findByMatricule(user.getMatricule());

	    if(existingUser != null) {
	        existingUser.setPassword(passwordencoder.encode(user.getPassword()));
	        existingUser.setRoles(user.getRoles());
	        existingUser.setEmail(user.getEmail());

	        user updatedUser = userepo.save(existingUser);

	        if (updatedUser != null && updatedUser.getId() > 0) {
	            return ResponseEntity.ok("User was updated successfully");
	        } else {
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error, User not updated");
	        }
	    } else {
	        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Error, User not found");
	    }
	}

	@DeleteMapping("/{matricule}")
	public ResponseEntity<Object> deleteUser(@PathVariable String matricule) {
	    user existingUser = userepo.findByMatricule(matricule);

	    if (existingUser != null) {
	        try {
	            userepo.delete(existingUser);
	            return ResponseEntity.ok("User was deleted successfully");
	        } catch (Exception e) {
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error deleting user: " + e.getMessage());
	        }
	    } else {
	        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
	    }
	}

  /* @PostMapping(path="/save")
  public String saveuser(@RequestBody userDTO userDTO) {
	   userservice.adduser(userDTO);
	   return "user added succesfully";
   }*/
   @PostMapping(path="/login")
   public ResponseEntity<?> loginuser(@RequestBody loginDTO loginDTO) {
 	  loginmessage loginmessage= userservice.loginuser(loginDTO);
	  
 	   return ResponseEntity.ok(loginmessage);
    }
   @GetMapping("{matricule}")
	public user getuserdetails(@PathVariable String matricule ) {
		return userservice.getuser(matricule) ;
		
	}
   @GetMapping(value ="all" )
  // @PreAuthorize("hasAuthority('ADMIN')")
	public List<user> getusers(){
	return userservice.getallusers();
	}
    @GetMapping("single")
  //  @PreAuthorize("hasAuthority('ADMIN') or hasAuthority('USER')")
    public ResponseEntity<Object> getMyDetails(){
        return ResponseEntity.ok(userepo.findByEmail(getLoggedInUserDetails().getUsername()));
    }

    public UserDetails getLoggedInUserDetails(){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if(authentication != null && authentication.getPrincipal() instanceof UserDetails){
            return (UserDetails) authentication.getPrincipal();
        }
        return null;
    }

}
