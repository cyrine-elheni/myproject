package com.example.pfe.service;

import java.util.List;

import com.example.pfe.model.metrics;
import com.example.pfe.model.metricsDTO;

public interface metricsinterface {
	public void createmetrics(metricsDTO metricsDTO);
	public String updatemetrics (metrics metrics);
    public String deletemetrics (String metricsid);
    public metrics getmetrics(String metricsid);
    public List<metrics> getallprojects();
	
}
