package com.example.pfe.model.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.pfe.model.user;
import com.example.pfe.model.userDTO;
@Repository

public interface userepository extends JpaRepository<user,Long>  {

	user findByMatricule(String Matricule);

	Optional<user> findOneByMatriculeAndPassword(String matricule,String password);


	Optional<user> findByEmail(String username);
	
	userDTO save(userDTO userDTO);

	
	
   
}
