package com.example.pfe.model.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.pfe.model.metrics;
@Repository

public interface metricsrepository extends JpaRepository<metrics,Long>{

	metrics findByDatamodelAndValeur(String datamodel, String valeur);



	



}
