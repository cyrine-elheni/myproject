package com.example.pfe.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.pfe.model.expected_metrics;
import com.example.pfe.model.metrics;
import com.example.pfe.model.metricsDTO;
import com.example.pfe.model.projet;
import com.example.pfe.model.resultat;
import com.example.pfe.model.repository.metricsrepository;
import com.example.pfe.model.repository.projetrepository;
import com.example.pfe.model.repository.projetstbrepository;
import com.example.pfe.model.repository.stbrepository;
import com.example.pfe.model.stb;
import com.example.pfe.model.stbDTO;
import com.example.pfe.model.stbprojet;

@Service
public class stbservice implements stbinterface {

    private final stbrepository stbrepo;
    private final projetrepository projetrepo;
    private final metricsrepository metricsrepo;
    private final projetstbrepository projetstbrepo;
    private final projetservice projetservice;

    private static final Logger logger = LoggerFactory.getLogger(stbservice.class);

    @Autowired
    public stbservice(stbrepository stbrepo, projetrepository projetrepo, metricsrepository metricsrepo,
            projetstbrepository projetstbrepo, projetservice projetservice) {
        super();
        this.stbrepo = stbrepo;
        this.projetrepo = projetrepo;
        this.metricsrepo = metricsrepo;
        this.projetstbrepo = projetstbrepo;
        this.projetservice = projetservice;
    }

    @Override
    @Transactional
    public stb updatestb(stbDTO stbDTO) {
        stb stbToUpdate = stbrepo.findById(stbDTO.getSid()).orElse(null);

        if (stbToUpdate != null) {
            if (stbToUpdate.getMetricslist() != null) {
                stbToUpdate.getMetricslist().clear();
            } else {
                stbToUpdate.setMetricslist(new ArrayList<>());
            }

            if (stbDTO.getMetrics() != null) {
                for (metricsDTO metricsDTO1 : stbDTO.getMetrics()) {
                    metrics existingMetrics = metricsrepo.findByDatamodelAndValeur(metricsDTO1.getDatamodel(), metricsDTO1.getValeur());

                    metrics metrics1 = existingMetrics != null ? existingMetrics : new metrics();

                    metrics1.setDatamodel(metricsDTO1.getDatamodel());
                    metrics1.setValeur(metricsDTO1.getValeur());
                    metrics1.setStb(stbToUpdate);
                    stbToUpdate.getMetricslist().add(metrics1);
                    metricsrepo.save(metrics1);
                }
            }

            return stbrepo.save(stbToUpdate);
        } else {
            stb stb1 = new stb();
            stb1.setSid(stbDTO.getSid());
            stb1.setAndroid(stbDTO.getAndroid());

            if (stb1.getMetricslist() == null) {
                stb1.setMetricslist(new ArrayList<>());
            }

            if (stbDTO.getMetrics() != null) {
                for (metricsDTO metricsDTO1 : stbDTO.getMetrics()) {
                    metrics metrics1 = new metrics();
                    metrics1.setDatamodel(metricsDTO1.getDatamodel());
                    metrics1.setValeur(metricsDTO1.getValeur());
                    metrics1.setStb(stb1);
                    stb1.getMetricslist().add(metrics1);
                    metricsrepo.save(metrics1);
                }
            }

            return stbrepo.save(stb1);
        }
    }

    @Override
    public void deletestb(String sid) {
        Optional<stb> optionalStb = stbrepo.findById(sid);

        if (optionalStb.isPresent()) {
            stb stbToDelete = optionalStb.get();
            
            stbToDelete.getMetricslist().forEach(metricsrepo::delete);

            stbrepo.delete(stbToDelete);
        } else {
        }
    }


    @Override
    public stb getstb(String stbid) {
        return stbrepo.findById(stbid).orElse(null);
    }

    @Override
    public List<metrics> getstbmetrics(String stbid) {
        stb stb1 = stbrepo.findById(stbid).orElse(null);
        if (stb1 != null) {
            return stb1.getMetricslist();
        }
        return null;
    }

    @Override
    public List<stb> getallstbs() {
        return stbrepo.findAll();
    }

    @Override
    public void addstbtoprojet(String pid, String sid) {
        Optional<projet> optionalProjet = projetrepo.findById(pid);
        Optional<stb> optionalStb = stbrepo.findById(sid);

        if (optionalProjet.isPresent() && optionalStb.isPresent()) {
            projet Projet = optionalProjet.get();
            stb Stb = optionalStb.get();
            List<stb> stbs = Projet.getStbs();
            stbs.add(Stb);
            projetrepo.save(Projet);
        } else {
            if (!optionalStb.isPresent()) {
                stb Stb = new stb();
                Stb.setSid(sid);
                stbrepo.save(Stb);
            }
        }
    }

    @Override
    public stb createstb(stbDTO stbDTO) {
        stb stb1 = new stb();
        stb1.setSid(stbDTO.getSid());
        stb1.setAndroid(stbDTO.getAndroid());

        if (stb1.getMetricslist() == null) {
            stb1.setMetricslist(new ArrayList<>());
        }

        if (stbDTO.getMetrics() != null) {
            for (metricsDTO metricsDTO1 : stbDTO.getMetrics()) {
                metrics metrics1 = new metrics();
                metrics1.setDatamodel(metricsDTO1.getDatamodel());
                metrics1.setValeur(metricsDTO1.getValeur());
                metrics1.setStb(stb1);
                stb1.getMetricslist().add(metrics1);
                metricsrepo.save(metrics1);
            }
        }

        return stbrepo.save(stb1);
    }

    @Override
    public String getprojetbysid(String sid) {
        Optional<stbprojet> stbProjetOptional = projetstbrepo.findById(sid);
        if (stbProjetOptional.isPresent()) {
            stbprojet stbProjet = stbProjetOptional.get();
            return stbProjet.getProjet_pid();
        }
        return null;
    }

    @Override
    public resultat comparemetrics(String stbSid) {

        List<metrics> stbMetrics = getstbmetrics(stbSid);
        List<expected_metrics> expectedMetrics = projetservice.getprojetmetrics(getprojetbysid(stbSid));

        resultat comparisonResult = new resultat();

        for (int i = 0; i < stbMetrics.size(); i++) {
            metrics stbMetric = stbMetrics.get(i);

            expected_metrics expectedMetric = null;
            for (expected_metrics em : expectedMetrics) {
                if (em.getExpected_datamodel().equals(stbMetric.getDatamodel())) {
                    expectedMetric = em;
                    break;
                }
            }

            if (expectedMetric != null) {
                boolean metricComparisonResult = compareValeurs(stbMetric, expectedMetric);
                comparisonResult.addMetricComparison(stbMetric.getDatamodel(), stbMetric.getValeur(), metricComparisonResult);
            } else {
                comparisonResult.addMetricComparison(stbMetric.getDatamodel(), "N/A", false);
            }
        }

        return comparisonResult;
    }

    public boolean compareDataModels(List<metrics> stbmetrics, List<expected_metrics> expectedmetrics) {

        if (stbmetrics != null && !stbmetrics.isEmpty() && expectedmetrics != null) {

            String stbDataModel = stbmetrics.get(0).getDatamodel();

            String expectedDataModel = expectedmetrics.get(0).getExpected_datamodel();

            return stbDataModel.equals(expectedDataModel);

        }else {
        	
        	return  false;
        }

    

    }


    public boolean compareValeurs(metrics stbmetrics, expected_metrics expectedmetrics) {

        if (stbmetrics != null && expectedmetrics != null) {

            String stbDataModel = stbmetrics.getDatamodel();

            switch (stbDataModel) {

                case "SerialNumber": {
                    String stbSerialNumber = stbmetrics.getValeur();
                    if (stbSerialNumber.length() == 15 && stbSerialNumber.startsWith("SG")) {
                        return true; 
                    } else {
                        return false;
                    }
                }

                case "GoogleSerialNumber": {
                    String GoogleSerialNumber = stbmetrics.getValeur();
                    if (GoogleSerialNumber.length() == 12) {
                        return true; 
                    } else {
                        return false; 
                    }
                }

                case "Manufacturer": {
                    String Manufacturer = stbmetrics.getValeur();
                    if (Manufacturer.startsWith("ro.product.manufacturer")) {
                        return true; 
                    } else {
                        return false; 
                    }
                }

                case "CECStatus": {
                    String CECStatus = stbmetrics.getValeur();
                    if (CECStatus.equals("enable") || CECStatus.equals("disable")) {
                        return true;
                    } else {
                        return false;
                    }
                }

      case "CECVolume": {
                    String CECVolume = stbmetrics.getValeur();
                    if (CECVolume.equals("enable") || CECVolume.equals("disable")) {
                        return true;
                    } else {
                        return false;
                    }
                }
                  case "Prefer50Hz": {
                    String Prefer50Hz = stbmetrics.getValeur();
                    if (Prefer50Hz.equals("enable") || Prefer50Hz.equals("disable")) {
                        return true;
                    } else {
                        return false;
                    }
                }
                  case "PreferHDR": {
                    String PreferHDR = stbmetrics.getValeur();
                    if (PreferHDR.equals("Auto") || PreferHDR.equals("SDR")|| PreferHDR.equals("HDR")) {
                        return true;
                    } else {
                        return false;
                    }
                }
                 case "ResolutionMode": {
                    String ResolutionMode = stbmetrics.getValeur();
                    if (ResolutionMode.equals("Auto") || ResolutionMode.equals("Manual")) {
                        return true;
                    } else {
                        return false;
                    }
                }  case "MuteStatus": {
                    String MuteStatus = stbmetrics.getValeur();
                    if (MuteStatus.equals("enable") || MuteStatus.equals("disable")) {
                        return true;
                    } else {
                        return false;
                    }
                }
                default:
                    String stbvaleur = stbmetrics.getValeur();
                    String expectedvaleur = expectedmetrics.getExpected_valeur();
                    return stbvaleur.equals(expectedvaleur);
            }

        }

        return false;



    }
}
