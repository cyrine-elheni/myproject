package com.example.pfe.controller;
import com.example.pfe.service.*;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.pfe.model.metrics;
import com.example.pfe.model.metricsDTO;
import com.example.pfe.model.resultat;
import com.example.pfe.model.stb;
import com.example.pfe.model.stbDTO;
import com.example.pfe.model.stbprojet;
import com.example.pfe.model.stbprojetDTO;
import com.example.pfe.service.stbservice;
@CrossOrigin
@RestController
@RequestMapping(path = "stbsima")
public class stbcontroller {

private final stbservice stbservice;
private final metricservice metricservice;	
	
	@Autowired
	public stbcontroller(stbservice stbservice,metricservice metricservice) {
	this.stbservice= stbservice;
	this.metricservice=metricservice;
	}
	
	
		

	@GetMapping("/projet/{sid}")
	public String getstb(@PathVariable String sid ) {
		return stbservice.getprojetbysid(sid) ;
		
	}
	
	@GetMapping("{sid}")
	public stb getstbdetails(@PathVariable String sid ) {
		return stbservice.getstb(sid) ;
		
	}
	
	@GetMapping("/compare/{stbSid}")
    public resultat compareMetrics(@PathVariable String stbSid) {
        return stbservice.comparemetrics(stbSid);
    }
	@GetMapping("/metrics/{sid}")
	public List<metrics> getstbmetrics(@PathVariable String sid ) {
		return stbservice.getstbmetrics(sid) ;
		
	}
	
	
	@GetMapping(value ="all" )
	public List<stb> getstb(){
	return stbservice.getallstbs();
	}


      @PutMapping("/update")
	    public ResponseEntity<?> updateStb(@RequestBody stbDTO stbDTO) {
	        stb updatedStb = stbservice.updatestb(stbDTO);
	        if (updatedStb != null) {
	            return ResponseEntity.ok("stb created or updated successfully");
	        } else {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Le STB n'a pas pu être mis à jour");
	        }
	    }
      @PostMapping("/create")
      public ResponseEntity<String> createSTBWithMetrics(@RequestBody stbDTO stbDTO) {
          stb createdSTB = stbservice.createstb(stbDTO);
          if (createdSTB != null) {
              return ResponseEntity.ok("STB created successfully");
          } else {
              return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to create STB");
          }
      }
  	

	@PostMapping("/addstbtoprojet")
	public String addstbtoprojetdetails(@RequestBody stbprojetDTO dto) {
		  stbservice.addstbtoprojet(dto.getPid(), dto.getSid());
		 return "stb added successfully";	
	}

	@DeleteMapping("{sid}")
	public String deletestbdetails(@PathVariable String sid  ) {
		 stbservice.deletestb(sid)  ;
		 return "stb deleted successfully";
		
	}

}
