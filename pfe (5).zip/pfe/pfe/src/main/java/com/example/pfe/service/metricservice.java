package com.example.pfe.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.pfe.model.repository.*;
import com.example.pfe.model.metrics;
import com.example.pfe.model.metricsDTO;
import com.example.pfe.model.stb;
import com.example.pfe.service.metricsinterface;

import jakarta.transaction.Transactional;
@Transactional
@Service
public class metricservice implements metricsinterface  {
	private final metricsrepository metricsrepo;

	@Autowired
	public metricservice(metricsrepository metricsrepo) {
	super();
	this.metricsrepo = metricsrepo;

	}
	
	@Override
	public void createmetrics(metricsDTO metricsDTO) {
		 metrics metrics1 = new metrics();
		// metrics1.setMid(metricsDTO.getMid());
		 metrics1.setDatamodel(metricsDTO.getDatamodel());
		 metrics1.setValeur(metricsDTO.getValeur());
	        metricsrepo.save(metrics1);
	}
	@Override
	public String updatemetrics(metrics metrics) {
		metricsrepo.save(metrics);
		return "success";
	}
/*
	@Override
	public String deletemetrics(String metricsid) {
		metricsrepo.deleteByDatamodel(metricsid);
		return "success";
	}

	@Override
	public metrics getmetrics(String metricsid) {
		return metricsrepo.findById(metricsid).get();
	}
*/
	@Override
	public List<metrics> getallprojects() {
		 return metricsrepo.findAll();
	}

	@Override
	public String deletemetrics(String metricsid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public metrics getmetrics(String metricsid) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
