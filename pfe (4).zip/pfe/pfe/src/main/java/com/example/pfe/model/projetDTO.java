package com.example.pfe.model;

import java.util.List;

public class projetDTO {
    private String pid;
    private String pname;
    private List<expected_metricsDTO> expected_metrics;

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public List<expected_metricsDTO> getExpected_metrics() {
        return expected_metrics;
    }

    public void setExpected_metrics(List<expected_metricsDTO> expected_metrics) {
        this.expected_metrics = expected_metrics;
    }
}
