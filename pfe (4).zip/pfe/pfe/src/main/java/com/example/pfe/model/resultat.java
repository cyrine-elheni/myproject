package com.example.pfe.model;

import java.util.ArrayList;
import java.util.List;

public class resultat {
	private List<metricscomparaison> metricComparisons;
    private boolean overallSuccess;

    public resultat() {
        this.metricComparisons = new ArrayList<>();
    }

    public List<metricscomparaison> getMetricComparisons() {
        return metricComparisons;
    }

    public void addMetricComparison(String dataModel, String value, boolean success) {
        metricComparisons.add(new metricscomparaison(dataModel, value, success));
        if (!success) {
            this.overallSuccess = false;
        }
    }

    public boolean isOverallSuccess() {
        return overallSuccess;
    }

}