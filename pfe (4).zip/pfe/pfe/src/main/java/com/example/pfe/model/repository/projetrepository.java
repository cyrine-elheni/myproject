package com.example.pfe.model.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.pfe.model.projet;
import com.example.pfe.model.projetDTO;
@Repository
public interface projetrepository extends JpaRepository<projet,String> {

	


         
	    
}