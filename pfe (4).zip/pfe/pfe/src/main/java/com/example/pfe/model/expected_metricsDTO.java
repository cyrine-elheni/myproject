package com.example.pfe.model;

public class expected_metricsDTO {
	    private String expected_datamodel;
	    private String expected_valeur;
		
		public String getExpected_datamodel() {
			return expected_datamodel;
		}
		public void setExpected_datamodel(String expected_datamodel) {
			this.expected_datamodel = expected_datamodel;
		}
		public String getExpected_valeur() {
			return expected_valeur;
		}
		public void setExpected_valeur(String expected_valeur) {
			this.expected_valeur = expected_valeur;
		}

}
