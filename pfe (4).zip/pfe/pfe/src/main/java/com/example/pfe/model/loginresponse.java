package com.example.pfe.model;

public class loginresponse {
private String jwtToken;
public loginresponse(String jwtToken) {
	this.jwtToken=jwtToken;
}
}
