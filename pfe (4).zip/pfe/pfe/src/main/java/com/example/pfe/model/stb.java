package com.example.pfe.model;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Entity
@Data
@Table(name="stb")
public class stb {
	@Id
	@Column(name = "sid")
	private String sid;

	
	public String getAndroid() {
		return android;
	}




	@Column(name = "android")
	private String android;


	public String getSid() {
		return sid;
	}
	
	public List<metrics> getMetricslist() {
		return metricslist;
	}
	public void setMetricslist(List<metrics> metricslist) {
		this.metricslist = metricslist;
	}



	@JsonManagedReference
	@OneToMany(mappedBy="stb")
private List<metrics> metricslist ;

	public void setSid(String sid) {
		this.sid = sid;
		
	}

	public void setAndroid(String android) {
		this.android = android;		
	}

	



	}



