package com.example.pfe.config;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.pfe.model.repository.userepository;
import com.example.pfe.model.*;
@Service
public class userinfoservice implements UserDetailsService  {
@Autowired
private userepository userepo;
@Autowired
public userinfoservice() {
    this.userepo = userepo;
}

	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        Optional<user> user = userepo.findByEmail(email);
        return user.map(OurUserInfoDetails::new).orElseThrow(()->new UsernameNotFoundException("User Does Not Exist"));
	}

}
