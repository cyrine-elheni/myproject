package com.example.pfe.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Data
@Table(name="projet_stbs")
public class stbprojet {

	public String getStbs_sid() {
		return stbs_sid;
	}
	public void setStbs_sid(String stbs_sid) {
		this.stbs_sid = stbs_sid;
	}
	public String getProjet_pid() {
		return projet_pid;
	}
	public void setProjet_pid(String projet_pid) {
		this.projet_pid = projet_pid;
	}
	@Id
	@Column(name = "stbs_sid")

	
    private String stbs_sid;
	@Column(name = "projet_pid")

	private String projet_pid;
}
