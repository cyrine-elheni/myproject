package com.example.pfe.model.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.pfe.model.stb;

@Repository
public interface stbrepository extends JpaRepository<stb, String> {
    Optional<stb> findBySid(String sid);
}

