package com.example.pfe.model;

public class metricscomparaison {
	  public metricscomparaison(String r_dataModel, String r_value, boolean success) {
		super();
		this.r_dataModel = r_dataModel;
		this.r_value = r_value;
		this.success = success;
	}
	public String getR_dataModel() {
		return r_dataModel;
	}
	public void setR_dataModel(String r_dataModel) {
		this.r_dataModel = r_dataModel;
	}
	public String getR_value() {
		return r_value;
	}
	public void setR_value(String r_value) {
		this.r_value = r_value;
	}
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	private String r_dataModel;
      private String r_value;
      private boolean success;

      

    
}
