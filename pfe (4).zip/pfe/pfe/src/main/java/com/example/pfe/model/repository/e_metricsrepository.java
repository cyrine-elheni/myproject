package com.example.pfe.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.pfe.model.expected_metrics;
@Repository
public interface e_metricsrepository extends JpaRepository<expected_metrics,String> {

}
